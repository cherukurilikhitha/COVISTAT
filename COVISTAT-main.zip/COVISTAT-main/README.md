Select desired State, Category(confirmed, deceased, recovered....), Data Type(cumulative, daily), date range and a graph gets displayed according to the input given.

Website link: https://covistat.azurewebsites.net/

Snapshots of Website

![1](https://user-images.githubusercontent.com/75263348/143900913-2f1eb4e2-4d2f-406f-bb97-7438b08ece96.png)

![image](https://user-images.githubusercontent.com/75263348/143901572-80c202f6-7e47-4018-bce3-82c2c019d5cf.png)

![image](https://user-images.githubusercontent.com/75263348/143902604-908c6b55-4084-466f-82c9-0dc59c84f1cb.png)

![image](https://user-images.githubusercontent.com/75263348/143903113-be5572ea-6cde-4f41-9794-91bd2930b77a.png)
